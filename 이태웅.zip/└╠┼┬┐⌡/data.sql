CREATE TABLE a_data (
    animal_age VARCHAR2(50)PRIMARY KEY,                  
    animal_korean_name VARCHAR2(50),        
    animal_sex_dist VARCHAR2(50),           
    cites VARCHAR2(50),                     
    clinical_last_diagnosis VARCHAR2(100),  
    class_name VARCHAR2(50)              
);