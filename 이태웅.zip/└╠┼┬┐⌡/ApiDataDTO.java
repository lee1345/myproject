package opendata2;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
import opendata.ApiDataDTO.Item;

@Data
@NoArgsConstructor
public class ApiDataDTO {

	@Data
	@NoArgsConstructor
	public static class response{
    private body body;
    private header header;
	}


    @Data
    @NoArgsConstructor
    public static class body {
        private items items;
     	private int numOfRows;
        private int pageNo;
        private int totalCount; 
    }

    @Data
    @NoArgsConstructor
    public static class header {
        private String resultCode;
        private String resultMsg;
    }
    @Data
    @NoArgsConstructor
    public static class items {
    	private String item;
    }

    @Data
    @NoArgsConstructor
    
    public static class item {
        private String animalAge;        		// 동물 나이 (ANML_AGE)
        private String animalKoreanName; 		// 동물 한국명 (ANML_KRLNG_NM)
        private String animalSexDist;    		// 동물 성별 구분 (ANML_SXDST)
        private String cites;           		 // CITES (멸종위기종 목록 여부)
        private String clinicalLastDiagnosis;	 // 임상 마지막 진단 (CLINICAL_LAST_DGNSS)
        private String className;        		// 동물 분류 (CLSS)
    }
}