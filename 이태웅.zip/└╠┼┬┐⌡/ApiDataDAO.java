package opendata2;

public class ApiDataDAO {

}
